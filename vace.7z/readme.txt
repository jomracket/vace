15 Nov 1998

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or (at
your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.


The ROM?
	The distribution includes a copy of the Jupiter ACE ROM image. 
	AFAIK there are no problems with this - I have asked Boldfield 
	Computing if they mind it being here and I the answer can be 
	found in boldcomp.txt, they also offer some original ACE tapes.
	http://members.aol.com/boldcomp/page.htm 

Version:
	V1.0 First distribution. (Needs MFC shared .dlls)

	The emulator is up and running. I've added some loading and
	save capabilities. There is still no sound implemented yet.

Description:
	This emulator is made by me, Edward Patel. The Jupiter ACE 
	is the real *outsider* micro from the 80's. Instead of having
	BASIC as the programming language it had FORTH. It was designed
	by two guys how had worked at Sinclair Research Ltd and was
	responsible for the famous Sinclair ZX81 and ZX Spectrum. 
	They are Steven Vickers and Richard Altwasser.
	For a FAQ (1997) see http://users.aol.com/autismuk/ace/faq.htm

	I made it for the fun of it. As a base I used Russell Marks
	ZX81 emulator xz81. Which he based on Ian Collier xz80, a 
	ZX Spectrum emulator for X. The xz81 can be found (1997) at
	ftp://sunsite.unc.edu/pub/Linux/system/emulators/zx/z81-0.2.tar.gz

Others:
	Paul Robson (autismuk@aol.com) has made a DOS version and is also
	the maintainer of the FAQ mentioned earlier.

Credits:
	Steven Vickers and Richard Altwasser
	Russell Marks
	Ian Collier (Ian.Collier@comlab.ox.ac.uk)
	Paul Robson (autismuk@aol.com)
	Michael Josefsson (mj@isy.liu.se)
	Ronald Kneusel (rkneusel@post.its.mcw.edu)	

Contact:
	e-mail: tiletech@hem.passagen.se
	
Share and enjoy! 

-Edward


"An idiot with a computer is a faster, better idiot" - Rich Julius
